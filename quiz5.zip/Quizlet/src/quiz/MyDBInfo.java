package quiz;

/*
 * CS108 Student: This file will be replaced when we test your code. So, do not add any of your
 * assignment code to this file. Also, do not modify the public interface of this file.
 * Only change the public MyDBInfo constants so that it works with the database login credentials 
 * that we emailed to you.
 */
public class MyDBInfo {
	
	public static final String MYSQL_USERNAME = "ccs108jzhang4";
	public static final String MYSQL_PASSWORD = "VHjNQkQK7jv3hCW8";
	public static final String MYSQL_DATABASE_SERVER = "mysql-user.stanford.edu";
	public static final String MYSQL_DATABASE_NAME = "c_cs108_jzhang4";

}
